package com.example.disneytour

import android.app.Activity
import android.content.Context
import android.content.Context.LAYOUT_INFLATER_SERVICE
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.inflate
import android.view.ViewGroup
import android.widget.*

class LocationListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_location_list)

        var sectionNames = resources.getStringArray(R.array.sectionNames)
        var sectionDetails = resources.getStringArray(R.array.sectionDetails)
        var sectionPhotos: Array<Int> = arrayOf(
            R.drawable.jungel_river_cruise,
            R.drawable.liki_tikis,
            R.drawable.castle,
            R.drawable.cinderella_carousel,
            R.drawable.flying_elephant,
            R.drawable.small_world,
            R.drawable.winniethe_pooh,
            R.drawable.tea_cups,
            R.drawable.hyperspace_mountain,
            R.drawable.iron_man,
            R.drawable.orbitron,
        )

        var sections = ArrayList<Section>()

        @Override
        for(i in 0 until sectionNames.size-1) {
            for (j in i+1 until sectionNames.size) {
                val c = Section(sectionNames[i], sectionDetails[i], sectionPhotos[i])
                sections.add(c)
            }
        }

        val listView: ListView = this.findViewById(R.id.listViewComplex)

        val listAdapter =
           SectionAdapter(this, R.layout.list_item, sections)
        listView.adapter = listAdapter

    }

    class SectionAdapter(
        context: Context,
        resource: Int,
        objects: MutableList<Section>
    ) : ArrayAdapter<Section>(context, resource, objects) {
        private var resource = resource
        private var sections = objects
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            var v = convertView
            if (v == null){
                val layoutInflater = context.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
                v = layoutInflater.inflate(resource, parent, false)
            }
            var imageView = v!!.findViewById<ImageView>(R.id.imageView)
            var textViewName = v!!.findViewById<TextView>(R.id.setionName)
            var textViewDetail = v!!.findViewById<TextView>(R.id.sectionDetails)
            imageView.setImageResource(sections[position].photo)
            textViewName.text = sections[position].name
            textViewDetail.text = sections[position].detail
            return v!!
        }
    }
    data class Section(val name : String, val detail : String, val photo : Int)
}